
	
	
		<!-- Blog SECTION -->
<?php $__env->startSection('content'); ?>

		<div>
			<div class="BlogHeader" data-aos="fade-up" data-aos-duration="1000">
				<h1>Create New Post </h1>
			</div>
</div>
<?php if($errors->any()): ?>
<div class="btn">
	<ul>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li>
<?php echo e($error); ?>

		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>
<?php endif; ?>

<div class="col-md-12">
	<form action="/blog" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<input
 type="text"
name="title"
placeholder="Title..."></input>
<textarea 
name="description"
placeholder="Description"
></textarea>
<div class="">
	<label>
		<span>
			Select a file
		</span>
		<input 
		type="file"
		name="image"
		class="hidden">
	</label>
</div>
<button
type="submit">
Submit Post
</button>
</form>
</div>

<?php $__env->stopSection(); ?>
	


<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxampp\htdocs\travel-blog\resources\views/blog/create.blade.php ENDPATH**/ ?>