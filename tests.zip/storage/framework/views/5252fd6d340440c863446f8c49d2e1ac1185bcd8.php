	
		<!-- Blog SECTION -->
		
            <div class="BlogSection" id="blog">
			<div class="BlogHeader-index" data-aos="fade-up" data-aos-duration="1000">
				<h1>Have a Look at my Articles About Traveling. </h1>
			</div>

           <?php if(session()->has('message')): ?>
                   <div class="btn">
	                  <?php echo e(session()->get('message')); ?>

                    </div>
            <?php endif; ?> 			
           <?php if(Auth::check()): ?>
                   <div class="btn sucsess">
                       <a href="/blog/create"> Create Post</a>
                   </div>
				   <?php endif; ?>
			
				  
                   <div class="BlogCards">
                   <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="col-lg-4">
				<div class="card one" data-aos="fade-up" data-aos-duration="1000">
					<img src="img/sunblock.png" class="cardoneImg" alt="" data-aos="fade-up" data-aos-duration="1100">
					<div class="cardbgone"></div>
					<div class="cardContent">
						<h2><?php echo e($blog->title); ?></h2>
						<p> By :  <?php echo e($blog->user->name); ?> </p>
						<span class="blog-date">Create on <?php echo e(date('jS M Y' , strtotime($blog->updated_at))); ?></span>
						<p><?php echo e($blog->description); ?></p>
						<a href="/blog/<?php echo e($blog->slug); ?>">
							<div class="cardBtn">
								<img src="img/next.png" alt="" class="cardIcon">
							</div>
						</a>
						<?php if(isset(Auth::user()->id) && Auth::user()->id == $blog->user_id): ?>
                     <span class="float-right">
                        <a 
                        href="/blog/<?php echo e($blog->slug); ?>/edit"
                        class="text-gray-700 italic hover:text-gray-900 pb-1 border-b-2">
                        Edit
                        </a>
                      </span>

                     <span class="float-right">
                     <form 
                        action="/blog/<?php echo e($blog->slug); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>

                        <button
						class="text-red-500 pr-3"
						type="submit">
						Delete
					</button>

                    </form>
                   </span>
                    <?php endif; ?>
        </div>
		
    </div> 
	
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
</div> 
</div>

	










<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxampp\htdocs\travel-blog\resources\views/blog/index.blade.php ENDPATH**/ ?>